package org.example.wallet.controller;

import org.example.wallet.model.Wallet;
import org.example.wallet.service.WalletService;
import org.example.wallet.dto.WalletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/wallets")
@RequiredArgsConstructor
public class WalletController {

    private final WalletService walletService;

    @GetMapping
    public ResponseEntity<String> test() {
        return ResponseEntity.ok("Wallet endpoint is working");
    }

    @PostMapping("/create")
    public ResponseEntity<?> createWallet(@RequestParam String owner) {
        try {
            Wallet wallet = walletService.createWallet(owner);
            return ResponseEntity.ok(wallet);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
        }
    }

    @PutMapping("/top-up")
    public ResponseEntity<?> topUp(@Valid @RequestBody WalletRequest request) {
        walletService.topUp(request);
        return ResponseEntity.ok("Top-up successful");
    }
}
