package org.example.wallet.service;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.example.wallet.dto.WalletRequest;
import org.example.wallet.model.Wallet;
import org.example.wallet.repository.WalletRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class WalletService {

    private final WalletRepository walletRepository;


    public Wallet createWallet(String owner) {
        return walletRepository.findByOwner(owner)
                .orElseGet(() -> {
                    Wallet wallet = new Wallet();
                    wallet.setOwner(owner);
                    wallet.setBalance(BigDecimal.ZERO);
                    return walletRepository.save(wallet);
                });
    }
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public void topUp(WalletRequest request) {
        Wallet wallet = walletRepository.findByOwner(request.getOwner())
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        wallet.setBalance(wallet.getBalance().add(request.getAmount()));
        walletRepository.save(wallet);

        try {
            addBonus(wallet);
        } catch (Exception e) {
            System.out.println("Bonus failed: " + e.getMessage());
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void addBonus(Wallet wallet) {
        wallet.setBalance(wallet.getBalance().add(BigDecimal.valueOf(5)));
        walletRepository.save(wallet);
        throw new RuntimeException("Simulated bonus rollback");
    }
}
