package org.example.wallet.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class WalletRequest {

    @NotBlank(message = "Owner name must not be blank")
    private String owner;

    @Positive(message = "Amount must be positive")
    private BigDecimal amount;
}
